module.exports = {
    komut: "ping", 
    açıklama: "Botun gecikme süresini ölçer.",
    kategori: "genel",
    alternatifler: ["ping","p","gecikmes","gecikmesuresi","gs"],
    kullanım: "k!ping",
    yetki: '',
};
                 
module.exports.baslat = (client, message) => {

    message.channel.send("Botun gecikme süresi: " + client.ping + " MS")

};