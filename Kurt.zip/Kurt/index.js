
// Değişkenler
const Discord = require("discord.js");
const chalk = require("chalk");
const Advanced = require('discordjs-advanced');
                         
const client = new Advanced.Client({
    token: "NjY1NDcxODk0NTcyNDk4OTY0.XhnA5w.YOFRfG-2k66lgVsy1fpaQHJc5Ig",
    prefix: "k!",
    sahip: ["407210917848154122"],
    komutDosya: "komutlar",
    veritabanı : {
        dosya:"database.json"
    },
    varsayılanKomutlar: ['yardım'],
    everyoneKapat: true

});                       
client.kategoriYükle([
    ['eglence', 'Eglence Komutları'],
    ['moderasyon', 'Moderasyon Komutları'],
    ['mullanıcı', 'Kullanıcı Komutları']
    ['genel', 'Genel Komutlar']
]);
                         
// Bot hazır mesajı
var log = chalk.bold.red("Bot başarıyla aktifleşti.")
var log01 = chalk.bold.green("Bot başarıyla aktifleşti.")


client.on("ready",() => {
console.log(log)
console.log(log01)
});

client.giris("NjY1NDcxODk0NTcyNDk4OTY0.XhnRXg.Co_e5HoFT4M21tuVk4L_keVO_zA");
